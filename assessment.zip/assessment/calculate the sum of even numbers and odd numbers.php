<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title></title>
</head>
<body>
   <form action="" method="post">
       <label for="add number">Add number</label>
       <input type="text" placeholder="add any number" name="number">
       <input type="submit" value="calculate" name="calculate">
   </form><br>
</body>
</html>
<?php
if (isset($_POST["calculate"])) {
   $num = $_POST["number"];
   $input = trim($num);
   $numbers = explode(",", $input);
   
$even_sum = 0;
$odd_sum = 0;
$even_product = 1;
$odd_product = 1;

foreach ($numbers as $number) {
   if ($number % 2 == 0) {
        $even_sum += $number;
        $even_product *= $number;
      } else {
        $odd_sum += $number;
        $odd_product *= $number;
      }
   }
   
   echo "Sum of even numbers: $even_sum\n"."<br>"."<br>";
   echo "Product of even numbers: $even_product\n"."<br>"."<br>";
   echo "Sum of odd numbers: $odd_sum\n"."<br>"."<br>";
   echo "Product of odd numbers: $odd_product\n"."<br>"."<br>";
}
?>