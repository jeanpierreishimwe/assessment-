<?php
/** The array_count_values function is used to count the number of repetition of each 
 * element in the array. The result is stored in an associative array where the keys 
 * are the elements and the values are their frequency of occurrence. The code then loops 
 * through the array and displays the 
 * number of times each element appears in the input array. */
$array = array(1, 2, 3, 2, 1, 4, 1);

$count = array_count_values($array);

foreach ($count as $key => $value) {
    echo "The number $key repeated $value times in the array.\n"."<br>";
}
?>

