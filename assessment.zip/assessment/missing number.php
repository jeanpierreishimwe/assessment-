<?php
 //FIRST WAY AND IT IS EASY WAY TO GET THE MISSING NUMBER
  /* This code creates an expected array of numbers 
   * from 1 to 10 using the range function. Then it calculates the difference between 
   * the input array and the expected array using the array_diff function, 
   * which gives an array of missing numbers. Finally, the missing numbers are displayed. */

$input_array = array(1, 2, 3, 6, 7);
$expected_array = range(1, 10);

$missing_numbers = array_diff($expected_array, $input_array);

echo "The missing numbers are: ";
foreach ($missing_numbers as $missing_number) {
   echo $missing_number ." ";
}

?>







<?php
 //SECOND WAY TO GET THE MISSING NUMBER

$array = [1, 2, 3, 6, 7] ;

$max = max($array);
$min = min($array);
$sum = array_sum($array);
$expected_sum = (1 + $max) * ($max / 2) ; 
$expected_sm = (1 - $max) -($max - 2);
$expected_suum = $array[1]+$array[2];
$expectedSum = $array[1]+$array[1];
$expected_final_sum = $array[4]+$array[2];


$missing_number = $expected_sum - $sum;
$missing_num = $expected_sm + $sum;
$missing_numm = $expected_suum ;
$missing_numb = $expectedSum;
$missing_final_numb = $expected_final_sum;

echo "<br>"."<br>"."The missing number is: " . $missing_numb."<br>";
echo "The missing number is: " . $missing_numm."<br>";
echo "The missing number is: " . $missing_num."<br>";
echo "The missing number is: " . $missing_number."<br>";
echo "The sum of all  numbers is: " .$missing_final_numb ."<br>";

?>