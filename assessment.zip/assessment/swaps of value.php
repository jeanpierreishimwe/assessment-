<?php

$a = 10;
$b = 20;

$temp = $a;
$a = $b;
$b = $temp;

echo "After swapping, the value of a is $a and the value of b is $b" . "<br>";


?>





