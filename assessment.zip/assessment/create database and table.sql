-- Create the database
CREATE DATABASE user_info;

-- Use the database
USE user_info;

-- Create the table
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(50)  NULL,
  last_name VARCHAR(50)  NULL,
  email VARCHAR(100)  NULL UNIQUE,
  password VARCHAR(255)  NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert user information into the table
INSERT INTO users (first_name, last_name, email, password)
VALUES ('jean', 'pierre', 'jeanpierreishimwe03@gmail.com', 'user123');

/*
This creates a database named user_info and a table named
users with columns id, first_name, last_name, email, password,
 created_at, and updated_at. The id column is set as the primary 
 key and auto-increments, email column is set to be unique and not
  null, and the created_at and updated_at columns
 store timestamps. Then it inserts a sample user into the users table.
*/